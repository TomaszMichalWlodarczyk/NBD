import com.basho.riak.client.api.RiakClient;
import com.basho.riak.client.api.commands.kv.DeleteValue;
import com.basho.riak.client.api.commands.kv.FetchValue;
import com.basho.riak.client.api.commands.kv.StoreValue;
import com.basho.riak.client.core.RiakCluster;
import com.basho.riak.client.core.RiakNode;
import com.basho.riak.client.core.query.Location;
import com.basho.riak.client.core.query.Namespace;
import com.basho.riak.client.core.query.RiakObject;
import com.basho.riak.client.core.util.BinaryValue;

import java.io.BufferedWriter;
import java.io.FileWriter;

public class RiakProject {

    //client object to interact with RiakKV
    private static RiakCluster setUpCluster() {

        //one node listening on 127.0.0.1:8087
        RiakNode node = new RiakNode.Builder()
                .withRemoteAddress("127.0.0.1")
                .withRemotePort(8087)
                .build();

        RiakCluster cluster = new RiakCluster.Builder(node).build();
        cluster.start();

        return cluster;
    }

    public static void main(String[] args) {
        try {

            String outputFile = "komunikaty.txt";
            BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile, true));

            RiakObject riakObject = new RiakObject()
                    .setContentType("text/plain")
                    .setValue(BinaryValue.create("myString"));

            Namespace myBucket = new Namespace("s4503");

            Location objectLocation = new Location(myBucket, "myKey");

            StoreValue storeOperation  = new StoreValue.Builder(riakObject)
                    .withLocation(objectLocation)
                    .build();

            RiakCluster cluster = setUpCluster();
            RiakClient client = new RiakClient(cluster);

            StoreValue.Response storeOpResp = client.execute(storeOperation);

            FetchValue fetchOp = new FetchValue.Builder(objectLocation)
                    .build();

            RiakObject fetchObject = client.execute(fetchOp).getValue(RiakObject.class);
            System.out.println("Object fetched from DB");
            System.out.println("Object: " + fetchObject.getValue().toString() + "\n");
            writer.append(fetchObject.getValue().toString());

            //update fetched object
            fetchObject.setValue(BinaryValue.create("myString updated"));
            StoreValue updateOp = new StoreValue.Builder(fetchObject)
                    .withLocation(objectLocation)
                    .build();
            StoreValue.Response updateOpResp = client.execute(updateOp);
            updateOpResp = client.execute(updateOp);

            FetchValue fetchOpAfterUpdate = new FetchValue.Builder(objectLocation).build();

            RiakObject fetchObjectAfterUpdate = client.execute(fetchOpAfterUpdate).getValue(RiakObject.class);
            System.out.println("Object fetched from DV after update");
            System.out.println("Object: " + fetchObjectAfterUpdate.getValue().toString() + "\n");
            writer.newLine();
            writer.append(fetchObjectAfterUpdate.getValue().toString());

            //delete the object
            DeleteValue deleteValue = new DeleteValue.Builder(objectLocation).build();
            client.execute(deleteValue);

            FetchValue fetchOpAfterDeletion = new FetchValue.Builder(objectLocation).build();
            RiakObject fetchObjectAfterDeletion = client.execute(fetchOpAfterDeletion).getValue(RiakObject.class);
            System.out.println("Object fetched from db after deletion");

            if (fetchObjectAfterDeletion == null) {
                writer.newLine();
                writer.append("There is no object");
                System.out.println("null, There is no object");
            } else {
                System.out.println(fetchObjectAfterDeletion.getValue().toString());
            }

            writer.close();

            //cluster shutdown
            cluster.shutdown();



        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
